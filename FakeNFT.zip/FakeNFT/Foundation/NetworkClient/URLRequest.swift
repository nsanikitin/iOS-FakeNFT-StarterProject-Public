//
//  URLRequest.swift
//  FakeNFT
//
//  Created by Рамиль Аглямов on 23.06.2024.
//
import Foundation

extension URLRequest {
    mutating func addHeaders(_ headers: [String: String]?) {
        headers?.forEach { key, value in
            self.setValue(value, forHTTPHeaderField: key)
        }
    }
}
