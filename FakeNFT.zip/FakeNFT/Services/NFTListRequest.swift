//
//  NFTListRequest.swift
//  FakeNFT
//
//  Created by Рамиль Аглямов on 23.06.2024.
//

import Foundation

struct NFTListRequest: NetworkRequest {
    var endpoint: URL? {
        URL(string: "https://d5dn3j2ouj72b0ejucbl.apigw.yandexcloud.net/api/v1/nft")
    }
    
    var headers: [String: String]? {
        [
            "Accept": "application/json",
//            "Authorization": "Bearer 61d3c8db-a147-4ae1-87cc-74329c18ff32", // ваш токен
            "X-Practicum-Mobile-Token": "61d3c8db-a147-4ae1-87cc-74329c18ff32" // ваш токен
        ]
    }
}
