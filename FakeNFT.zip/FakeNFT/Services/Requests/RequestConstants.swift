enum RequestConstants {
    #warning("insert your baseUrl <id>.mockapi.io")
    static let baseURL = ""
}
