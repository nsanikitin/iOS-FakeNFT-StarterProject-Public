//
//  NftListService.swift
//  FakeNFT
//
//  Created by Рамиль Аглямов on 23.06.2024.
//

import Foundation

typealias NftListCompletion = (Result<[NFTModel], Error>) -> Void

protocol NftListService {
    func loadNftList(completion: @escaping NftListCompletion)
}

