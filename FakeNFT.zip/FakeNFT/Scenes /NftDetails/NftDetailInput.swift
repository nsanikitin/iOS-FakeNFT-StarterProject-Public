public struct NftDetailInput {
    let id: String
}
