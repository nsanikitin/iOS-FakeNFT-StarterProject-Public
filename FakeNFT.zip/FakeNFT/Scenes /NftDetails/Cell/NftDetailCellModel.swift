import Foundation

struct NftDetailCellModel {
    let url: URL
}
