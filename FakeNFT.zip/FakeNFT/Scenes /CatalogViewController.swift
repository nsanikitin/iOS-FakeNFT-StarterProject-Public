//
//  CatalogViewController.swift
//  FakeNFT
//
//  Created by Anna on 20.06.2024.
//

import UIKit

final class CatalogViewController: UIViewController {
    
}
