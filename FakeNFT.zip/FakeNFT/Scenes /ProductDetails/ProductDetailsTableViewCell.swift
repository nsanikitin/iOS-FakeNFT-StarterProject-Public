import UIKit

final class ProductDetailsTableViewCell: UITableViewCell, ReuseIdentifying {}
